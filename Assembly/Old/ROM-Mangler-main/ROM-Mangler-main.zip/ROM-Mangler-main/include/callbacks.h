#ifndef CALLBACKS_H
#define CALLBACKS_H

#include <windows.h>

BOOL CALLBACK DlgProc(HWND hwnd, UINT Message, WPARAM wParam, LPARAM lParam);

#endif
