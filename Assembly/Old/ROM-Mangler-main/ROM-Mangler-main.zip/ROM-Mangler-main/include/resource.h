#define IDD_MAIN                        101
#define IDC_TEXT                        1000
#define IDC_NUMBER                      1001
#define IDC_LIST                        1002
#define IDC_ADD                         1003
#define IDC_CLEAR                       1004
#define IDC_REMOVE                      1005
#define IDC_SHOWCOUNT                   1006
#define IDG_SIZE			1007

#define IDC_SOURCE00			2000
#define IDC_SOURCE01			2001
#define IDC_SOURCE02			2002
#define IDC_SOURCE03			2003
#define IDC_SOURCE04			2004
#define IDC_SOURCE05			2005
#define IDC_SOURCE06			2006
#define IDC_SOURCE07			2007
#define IDC_SOURCE08			2008
#define IDC_SOURCE09			2009
#define IDC_SOURCE10			2010
#define IDC_SOURCE11			2011
#define IDC_SOURCE12			2012
#define IDC_SOURCE13			2013
#define IDC_SOURCE14			2014
#define IDC_SOURCE15			2015
#define IDC_SOURCE16			2016
#define IDC_SOURCE17			2017
#define IDC_SOURCE18			2018
#define IDC_SOURCE19			2019
#define IDC_SOURCE20			2020
#define IDC_SOURCE21			2021
#define IDC_SOURCE22			2022
#define IDC_SOURCE23			2023
#define IDC_SOURCE24			2024
#define IDC_SOURCE25			2025
#define IDC_SOURCE26			2026
#define IDC_SOURCE27			2027
#define IDC_SOURCE28			2028
#define IDC_SOURCE29			2029
#define IDC_SOURCE30			2030
#define IDC_SOURCE31			2031

#define IDC_DEST			2051
#define IDC_WRITE			2052
#define	IDC_SPLIT			2053

#define IDT_SOURCE00			2100
#define IDT_SOURCE01			2101
#define IDT_SOURCE02			2102
#define IDT_SOURCE03			2103
#define IDT_SOURCE04			2104
#define IDT_SOURCE05			2105
#define IDT_SOURCE06			2106
#define IDT_SOURCE07			2107
#define IDT_SOURCE08			2108
#define IDT_SOURCE09			2109
#define IDT_SOURCE10			2110
#define IDT_SOURCE11			2111
#define IDT_SOURCE12			2112
#define IDT_SOURCE13			2113
#define IDT_SOURCE14			2114
#define IDT_SOURCE15			2115
#define IDT_SOURCE16			2116
#define IDT_SOURCE17			2117
#define IDT_SOURCE18			2118
#define IDT_SOURCE19			2119
#define IDT_SOURCE20			2120
#define IDT_SOURCE21			2121
#define IDT_SOURCE22			2122
#define IDT_SOURCE23			2123
#define IDT_SOURCE24			2124
#define IDT_SOURCE25			2125
#define IDT_SOURCE26			2126
#define IDT_SOURCE27			2127
#define IDT_SOURCE28			2128
#define IDT_SOURCE29			2129
#define IDT_SOURCE30			2130
#define IDT_SOURCE31			2131

#define IDT_DEST			2200


#define IDR_1KB				3000
#define IDR_2KB				3001
#define IDR_4KB				3002
#define IDR_8KB				3003
#define IDR_16KB			3004
#define IDR_32KB			3005
#define IDR_64KB			3006
#define IDR_128KB			3007
#define IDR_256KB			3008
#define IDR_512KB			3009



#ifndef IDC_STATIC
  #define IDC_STATIC                   -1
#endif
